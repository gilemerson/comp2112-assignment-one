//template literal to eventually output html code and each game object's info for each entry

//keep track of the last clicked game entry
let selectedGame = 0;

//Trash Link
let linkTrash = document.getElementById('linkTrash');

//Inbox Link
let linkInbox = document.getElementById('inbox');

//Compose Link
let linkCompose = document.getElementById('compose');

//Delete Game Action
linkTrash.addEventListener('click', function(e) {
    e.preventDefault();
    let filtered = games.filter( game => game.deleted);
    selectedGame = 0;
    render(filtered);
});

linkInbox.addEventListener('click', function(e) {
    e.preventDefault();
    let inbox = games.filter( game => !game.deleted);
    selectedGame = 0;
    render(inbox);
});

linkCompose.addEventListener('click', composeForm)

function composeForm(e) {
    e.preventDefault();
    let html_composeForm = `
    <div class="pure-g">
    <div class="pure-u-1">
    <form id="newgame" class="pure-form pure-form-aligned" name="newgame">
    <fieldset>
        <div class="pure-control-group">
            <label for="gametitle">Game Title</label>
            <input id="gametitle" type="text" name="gametitle" placeholder="Title (Ex, Call of Duty)">
        </div>

        <div class="pure-control-group">
            <label for="publisher">Publisher</label>
            <input id="publisher" type="text" name="publisher" placeholder="Publisher Name">
        </div>

        <div class="pure-control-group">
        <label for="publishyear">Year Published</label>
        <input id="publishyear" name="publishyear" placeholder="Year">
        </div>

        <div class="pure-control-group">
        <label for="body">Body</label>
        <textarea id="body" name="body" class="pure-input-1-2" rows="10" cols="50"></textarea>
        </div>

        <div class="pure-control-group">
        <label for="avatarurl">Avatar URL</label>
        <input id="avatarurl" name="avatarurl" placeholder="URL">
        </div>

        <div class="pure-control-group">
        <label for="ifrmsrc">IFrame Source Url</label>
        <input id="ifrmsrc" name="ifrmsrc" placeholder="URL">
        </div>

        <div class="pure-controls">
        <button id="send" type="submit" class="pure-button pure-button-primary">Send</button>
        </div>
    </fieldset>
</form>
</div>
</div>
    `;

    let main = document.getElementById('main');
    main.innerHTML = html_composeForm;

    let send = document.getElementById('newgame');
    send.addEventListener('click', function (e) {
        e.preventDefault();


        //Compose Form
        let date = new Date();

        let obj_newGame = {
            subject : document.forms.newGame.subject.value,
            publisher : document.forms.newGame.publisher.value,
            date : date.toDateString(),
            body : document.forms.newGame.body.value,
            avatar : 'https://placem.at/people?h=50&w=50&random=1&txt=0',
            ifrmSrc : document.forms.newGame.ifrmSrc.value
        }
        //push our obj above to emails array
        games.unshift(obj.newGame);

        //use local storage to remember
        setLocalStorage();
    
        //update view of inbox
        linkInbox.click();

    });
}

function render (games) {

//use map on template literal to display all the entries
let displayGameSnippet = `
${games.map( (game, index) => `
<div class="email-item pure-g" data-id="${index}">
<div class="pure-u">
    <img width="64" height="64" alt="Tilo Mitra&#x27;s avatar" class="email-avatar" src=" ${game.avatar}">
</div>

<div class="pure-u-3-4">
    <h5 class="email-name">${game.subject}</h5>
    <h4 class="email-subject">${game.publisher}</h4>
    <p class="email-desc">
        ${game.body.length > 100 ? `${game.body.substr(0, 99)}...` : game.body}
    </p>
</div>
</div>
`).join('')}

`;

let el = document.getElementById('list');
el.innerHTML = displayGameSnippet;

initialize(games);

}

function initialize(games) {
    //add 'addEventListener'
    let gameList = [...(document.querySelectorAll('[data-id]'))];
    //add appropriate styles to make the items look selected
    gameList.map( (game, index) => game.addEventListener('click', function (e) {
        //remove the class from the previous game
        gameList[selectedGame].classList.remove('email-item-selected');
        game.classList.add('email-item-selected');
        selectedGame = index;
        showGameBody(index, games);
    }));

    //if the game exist, select the first one by default
    if(games.length) {
        gameList[selectedGame].classList.add('email-item-selected');
        showGameBody(selectedGame, games);
    }
    //delete button
    else {
        let main = document.getElementById('main');
        main.innerHTML = '<h1 style="color: #aaa">No Games</h1>';
    }

}

//shows the upper section of the main details (game title, publisher, ..)
function showGameBody(idx, games) {
let displayGameBody = `
<div class="email-content">
<div class="email-content-header pure-g">
    <div class="pure-u-1-2">
        <h1 class="email-content-title">${games[idx].subject}</h1>
        <p class="email-content-subtitle">
            Published By: <a>${games[idx].publisher}</a> in <span>${games[idx].date}</span>
        </p>
    </div>

    <div class="email-content-controls pure-u-1-2">
        <button id="delete" class="secondary-button pure-button ${games[idx].deleted ? 'btn-pressed' : ''}" data-id="${idx}">${games[idx].deleted ? 'Deleted' : 'Delete'}</button>
        <button class="secondary-button pure-button">Forward</button>
        <button class="secondary-button pure-button">Move to</button>
    </div>
</div>

<div class="email-content-body">
    <p>
       ${games[idx].ifrmSrc}
    </p>
</div>
</div>
`;

let main = document.getElementById('main');
main.innerHTML = displayGameBody;


let btn_delete = document.getElementById('delete');
btn_delete.addEventListener('click', () => deleteGame(btn_delete.dataset.id, games));

}

function deleteGame(index, games) {
    //if this current game does NOT have a key/value of delete:true
        if (!games[index].deleted) {

    //add key/value property  of deleted: true inside the currently selected game
    games[index].deleted = true;

    //use local storage to remember
    setLocalStorage();

    //update view of inbox
    let inbox = games.filter( game => !game.deleted);
    selectedGame = 0;
    render(inbox);
        }
        else {
    //this current email DOES have a key/value of delete:true
            delete games[index].deleted;
            let filtered = games.filter( game => game.deleted);
            selectedGame = 0;
            render(filtered);
        }
}

//Apply Local Storage
function setLocalStorage () {
    localStorage.setItem('items', JSON.stringify(games));
}

//if localStorage exists called 'items' then use it, else use global games.
if (localStorage.getItem('items')) {
    games = JSON.parse(localStorage.getItem('items'));
    let filtered = games.filter( game => !game.deleted);
    render(filtered);
}
else {
render(games);
}


